=== Plugin Name ===
Contributors: pie
Requires at least: 4.3.1
Tested up to: 4.7.2
Stable Tag: 1.0
